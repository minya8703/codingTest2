import java.util.Scanner;

public class P10986_220712 {
    // 나머지 합
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        
    }
}
